#  This script should start up your service on port 8080
