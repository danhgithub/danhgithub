#  This script should do all the preparation for your project to run, such as downloading any dependencies and compiling if necessary
