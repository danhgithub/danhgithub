#!/bin/sh
# This script runs backend server

java -cp /usr/share/java/gifserver.jar com.gifserver

